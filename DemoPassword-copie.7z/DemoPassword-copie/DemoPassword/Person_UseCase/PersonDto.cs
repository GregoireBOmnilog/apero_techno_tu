﻿namespace DemoPassword.Person_UseCase
{
    public record PersonDto(string FirstName, string LastName, string Email);
}
